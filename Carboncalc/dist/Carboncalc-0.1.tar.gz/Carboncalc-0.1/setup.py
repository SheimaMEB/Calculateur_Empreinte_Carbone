from setuptools import setup, find_packages

setup(
    name='Carboncalc',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'pandas',
        'matplotlib'
    ],
    description='Un package pour calculer les émissions de CO2 basées sur les données de consommation utilisateur',
    author='Votre Nom',
    author_email='votre.email@example.com',
    url='https://votre-repo-url',  # Mettez ici l'URL de votre dépôt si vous en avez un
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)
