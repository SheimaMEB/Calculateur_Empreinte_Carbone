# Carboncalc

Ce package contient des modules pour collecter des données de consommation utilisateur et calculer les émissions de CO2.
